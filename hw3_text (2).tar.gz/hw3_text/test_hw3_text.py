from unittest import result
import mugrade
import numpy as np

def objects_equal(value,ref):
    """ Test if two objects are equal according to our autograding rules.
    We have to do this manually so that numpy arrays are compard properly. """

    try:
        if isinstance(ref, dict):
            if sorted(value.keys()) != sorted(ref.keys()):
                return False
            for k,v in ref.items():
                if not objects_equal(v, value[k]):
                    return False
            return True
    
        elif isinstance(ref, list) or isinstance(ref, tuple):
            if len(value) != len(ref):
                return False
            for a,b in zip(ref, value):
                if not objects_equal(a, b):
                    return False
            return True
    
        elif isinstance(ref, np.ndarray):
            if value.shape != ref.shape:
                return False
            if not np.allclose(ref, value, atol=1e-8):
                return False
            return True
          
        elif isinstance(ref, float) or isinstance(ref, np.float32):
          return np.allclose(value, ref)
    
        else:
            return value == ref
    except:
        return False

def test_preprocess():
    with mugrade.test:
        assert preprocess("I'm doing well! How about you?") == ['im', 'doing', 'well', 'how', 'about', 'you']
    with mugrade.test:
        assert preprocess(" a..a. .a . a.") == ['a', 'a', 'a', 'a']
    with mugrade.test:
        assert preprocess("") == []
    with mugrade.test:
        assert preprocess("word-of-mouth self-esteem") == ['word', 'of', 'mouth', 'self', 'esteem']
    with mugrade.test:
        assert preprocess("you've") == ['youve']
    with mugrade.test:
        assert preprocess("She's") == ['she']
    with mugrade.test:
        assert preprocess("SHE'S") == ['she']
    with mugrade.test:
        assert preprocess("Cea'sar") == ['ceaar']
    with mugrade.test:
        assert preprocess("clap👏clap") == ['clap', 'clap']
    with mugrade.test:
        assert preprocess("hello http://t.co/WJs5bmRthU hello") == ['hello', 'hello']
    with mugrade.test:
        assert preprocess("RT @GOPconvention: #Oregon votes today. That means 62 days until the @GOPconvention! https://t.co/OoH9FVb7QS") == ['rt', 'gopconvention', 'oregon', 'votes', 'today', 'that', 'means', '62', 'days', 'until', 'the', 'gopconvention']
    with mugrade.test:
        assert preprocess("RT @DWStweets: The choice for 2016 is clear: We need another Democrat in the White House. #DemDebate #WeAreDemocrats http://t.co/0n5g0YN46f") == ['rt', 'dwstweets', 'the', 'choice', 'for', '2016', 'is', 'clear', 'we', 'need', 'another', 'democrat', 'in', 'the', 'white', 'house', 'demdebate', 'wearedemocrats']
    with mugrade.test:
        assert preprocess(".@TimKaine's guiding principle: the belief that you can make a difference through public service. https://t.co/YopSUeMqOX") == ['timkaine', 'guiding', 'principle', 'the', 'belief', 'that', 'you', 'can', 'make', 'a', 'difference', 'through', 'public', 'service']
    with mugrade.test:
        assert preprocess("Glad the Senate could pass a #THUD / MilCon / VetAffairs approps bill with solid provisions for Virginia: https://t.co/NxIgRC3hDi") == ['glad', 'the', 'senate', 'could', 'pass', 'a', 'thud', 'milcon', 'vetaffairs', 'approps', 'bill', 'with', 'solid', 'provisions', 'for', 'virginia']
    with mugrade.test:
        assert preprocess("RT @IndyThisWeek: An @rtv6 exclusive: @GovPenceIN sits down with @RafaelOnTV\nSee it Sunday morning at 8:30a on RTV6 and our RTV6 app. http:…") == ['rt', 'indythisweek', 'an', 'rtv6', 'exclusive', 'govpencein', 'sits', 'down', 'with', 'rafaelontv', 'see', 'it', 'sunday', 'morning', 'at', '8', '30a', 'on', 'rtv6', 'and', 'our', 'rtv6', 'app', 'http']

def submit_preprocess():
    mugrade.submit(preprocess("From Chatham Town Council to Congress, @RepRobertHurt has made a strong mark on his community. Proud of our work together on behalf of VA!"))
    mugrade.submit(preprocess("Thank you New Orleans, Louisiana!\n#MakeAmericaGreatAgain #VoteTrump\nhttps://t.co/tI1h9xT9GX https://t.co/0bf7BOlWEj"))
    mugrade.submit(preprocess("RT @GovPenceIN: Excited to announce today plans to build the Indiana Neuro-Diagnostic Institute in partnership w/ @CHNw https://t.co/hy4yRC…"))
    mugrade.submit(preprocess("RT @SenSanders: My dad was born in Poland. Do you know how many people ever asked me whether or not I was born in America? Nobody ever aske…"))
    mugrade.submit(preprocess("Positive relationships between faith groups &amp; law enforcement build more resilient communities https://t.co/6pfrSKVE72"))

def test_read_data():
    data_train, data_test = read_data()
    with mugrade.test:
        assert data_train[0] == (True, ['rt', 'gopconvention', 'oregon', 'votes', 'today', 'that', 'means', '62', 'days', 'until', 'the', 'gopconvention'])
    with mugrade.test:
        assert data_train[10] == (False, ['rt', 'sensanders', 'my', 'dad', 'was', 'born', 'in', 'poland', 'do', 'you', 'know', 'how', 'many', 'people', 'ever', 'asked', 'me', 'whether', 'or', 'not', 'i', 'was', 'born', 'in', 'america', 'nobody', 'ever', 'aske'])
    with mugrade.test:
        assert data_train[20] == (False, ['congrats', 'to', 'va', 'national', 'guard', 'wwii', 'army', 'veteran', 'cary', 'jarvis', 'for', 'being', 'decorated', 'as', 'a', 'knight', 'of', 'legion', 'of', 'honor', 'by', 'the', 'french', 'government'])
    with mugrade.test:
        assert data_test[0] == (None, ['a', 'comprehensive', 'look', 'at', 'the', 'many', 'lies', 'and', 'offenses', 'of', 'donald', 'trump'])
    with mugrade.test:
        assert data_test[10] == (None, ['tune', 'in', 'to', 'hardball', 'w', 'hardball', 'chris', 'tonight', 'at', '7pm', 'for', 'our', 'discussion', 'on', 'the', 'u', 's', 'mission', 'against', 'isil'])
    with mugrade.test:
        assert data_test[20] == (None, ['rt', 'govpencein', 'getting', 'ready', 'for', 'the', 'formal', 'dedication', 'of', 'the', 'wakeman', 'va', 'clinic', 'at', 'camp', 'atterbury'])

def submit_read_data():
    data_train, data_test = read_data()
    mugrade.submit(data_train[1])
    mugrade.submit(data_train[11])
    mugrade.submit(data_train[21])
    mugrade.submit(data_test[1])
    mugrade.submit(data_test[11])
    mugrade.submit(data_test[21])

def test_get_distribution():
    data_train, data_test = read_data()
    dist_train = get_distribution(data_train)
    dist_test = get_distribution(data_test)
    with mugrade.test:
        assert dist_train["pence"] == 320
    with mugrade.test:
        assert dist_train["kaine"] == 78
    with mugrade.test:
        assert dist_test["american"] == 23
    with mugrade.test:
        assert dist_test["obama"] == 18
    with mugrade.test:
        assert len(dist_train) == 17991

def submit_get_distribution():
    data_train, data_test = read_data()
    dist_train = get_distribution(data_train)
    dist_test = get_distribution(data_test)
    mugrade.submit(dist_test["pence"])
    mugrade.submit(dist_test["kaine"])
    mugrade.submit(dist_train["american"])
    mugrade.submit(dist_train["obama"])
    mugrade.submit(len(dist_test))

def test_create_features():
    data_train, data_test = read_data()
    train_features, train_labels, test_features = create_features(data_train, data_test)
    with mugrade.test:
        assert train_features.nnz == 231278
    with mugrade.test:
        assert test_features.shape == (1000, 4745)
    with mugrade.test:
        assert len(train_labels) == 17298
    with mugrade.test:
        assert train_labels[0] == True
    with mugrade.test:
        assert train_labels[1] == False
    with mugrade.test:
        assert objects_equal(train_features.data.mean(), 0.2529396796375968)

def submit_create_features():
    data_train, data_test = read_data()
    train_features, train_labels, test_features = create_features(data_train, data_test)
    mugrade.submit(test_features.nnz)
    mugrade.submit(train_features.shape)
    mugrade.submit(train_labels[-1])
    mugrade.submit(train_labels[-2])
    mugrade.submit(test_features.data.mean())

def test_train_classifier():
    data_train, data_test = read_data()
    X_train, y_train, _ = create_features(data_train, data_test)

    clf_1_0 = train_classifier(X_train, y_train, 1.0)
    with mugrade.test:
        assert str(type(clf_1_0)) == "<class 'sklearn.svm._classes.LinearSVC'>"
    with mugrade.test:
        assert clf_1_0.C == 1.0
    with mugrade.test:
        assert clf_1_0.penalty == "l2"
    with mugrade.test:
        assert clf_1_0.loss == "hinge"
    with mugrade.test:
        assert clf_1_0.fit_intercept == True
    with mugrade.test:
        assert clf_1_0.coef_.shape == (1, 4745)

    with mugrade.test:
        clf = train_classifier(X_train, y_train, 0.1)
        y_train_pred = clf.predict(X_train)
        assert objects_equal(sklearn.metrics.accuracy_score(y_train, y_train_pred), 0.8949589547924616)
    with mugrade.test:
        clf = train_classifier(X_train, y_train, 1.0)
        y_train_pred = clf.predict(X_train)
        assert objects_equal(sklearn.metrics.accuracy_score(y_train, y_train_pred), 0.9458318880795468)
    with mugrade.test:
        clf = train_classifier(X_train, y_train, 10.0)
        y_train_pred = clf.predict(X_train)
        assert objects_equal(sklearn.metrics.accuracy_score(y_train, y_train_pred), 0.9735229506301306)

def submit_train_classifier():
    data_train, data_test = read_data()
    X_train, y_train, _ = create_features(data_train, data_test)
    mugrade.submit(sklearn.metrics.accuracy_score(y_train, train_classifier(X_train, y_train, 0.3).predict(X_train)))
    mugrade.submit(sklearn.metrics.accuracy_score(y_train, train_classifier(X_train, y_train, 3.0).predict(X_train)))
    mugrade.submit(sklearn.metrics.accuracy_score(y_train, train_classifier(X_train, y_train, 30.0).predict(X_train)))

def test_evaluate_classifier():
    data_train, data_test = read_data()
    X_train, y_train, _ = create_features(data_train, data_test)
    with mugrade.test:
        assert objects_equal(evaluate_classifier(X_train, y_train, train_length=10000), [(0.8159452460229375, 0.8038593373111591), (0.8819796954314721, 0.8541207580431908), (0.9490116573745565, 0.8917251051893409), (0.9841810172206648, 0.8730377306527127)])
    with mugrade.test:
        assert objects_equal(evaluate_classifier(X_train, y_train, C=(0.5, 5.0), train_length=10000), [(0.9351312697926243, 0.8861834654586637), (0.975057597916458, 0.8800221668052092)])

def submit_evaluate_classifier():
    data_train, data_test = read_data()
    X_train, y_train, _ = create_features(data_train, data_test)
    mugrade.submit(evaluate_classifier(X_train, y_train, train_length=5000))
    mugrade.submit(evaluate_classifier(X_train, y_train, C=(0.5, 5.0), train_length=5000))

def test_predict_test():
    data_train, data_test = read_data()
    train_features, train_labels, test_features = create_features(data_train, data_test)
    test_labels_pred = predict_test(train_features, train_labels, test_features)
    with mugrade.test:
        assert len(test_labels_pred) == 1000
    with mugrade.test:
        assert test_labels_pred[:10].tolist() == [False, True, False, False, False, False, False, False, True, True]

def submit_predict_test():
    data_train, data_test = read_data()
    train_features, train_labels, test_features = create_features(data_train, data_test)
    test_labels_pred = predict_test(train_features, train_labels, test_features)
    mugrade.submit(test_labels_pred[10:20])
    mugrade.submit(test_labels_pred.mean())

